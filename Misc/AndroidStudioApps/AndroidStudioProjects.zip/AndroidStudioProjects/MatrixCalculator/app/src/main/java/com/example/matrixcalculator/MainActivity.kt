package com.example.matrixcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    private lateinit var num1EditText: TextInputEditText
    private lateinit var num2EditText: TextInputEditText
    private lateinit var num3EditText: TextInputEditText
    private lateinit var num4EditText: TextInputEditText
    private lateinit var num5EditText: TextInputEditText
    private lateinit var num6EditText: TextInputEditText
    private lateinit var num7EditText: TextInputEditText
    private lateinit var num8EditText: TextInputEditText

    private lateinit var result1TextView: TextView
    private lateinit var result2TextView: TextView
    private lateinit var result3TextView: TextView
    private lateinit var result4TextView: TextView

    private lateinit var addButton: Button
    private lateinit var subtractButton: Button
    private lateinit var multiplyButton: Button
    private lateinit var resetButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1EditText = findViewById(R.id.num1EditText)
        num2EditText = findViewById(R.id.num2EditText)
        num3EditText = findViewById(R.id.num3EditText)
        num4EditText = findViewById(R.id.num4EditText)
        num5EditText = findViewById(R.id.num5EditText)
        num6EditText = findViewById(R.id.num6EditText)
        num7EditText = findViewById(R.id.num7EditText)
        num8EditText = findViewById(R.id.num8EditText)

        result1TextView = findViewById(R.id.textView1)
        result2TextView = findViewById(R.id.textView2)
        result3TextView = findViewById(R.id.textView3)
        result4TextView = findViewById(R.id.textView4)

        addButton = findViewById(R.id.button)
        subtractButton = findViewById(R.id.button2)
        multiplyButton = findViewById(R.id.button3)
        resetButton = findViewById(R.id.button6)

        addButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val num3 = num3EditText.text.toString().toDouble()
            val num4 = num4EditText.text.toString().toDouble()
            val num5 = num5EditText.text.toString().toDouble()
            val num6 = num6EditText.text.toString().toDouble()
            val num7 = num7EditText.text.toString().toDouble()
            val num8 = num8EditText.text.toString().toDouble()

            val result1 = num1 + num5
            val result2 = num2 + num6
            val result3 = num3 + num7
            val result4 = num4 + num8
            result1TextView.text = result1.toString()
            result2TextView.text = result2.toString()
            result3TextView.text = result3.toString()
            result4TextView.text = result4.toString()
        }

        subtractButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val num3 = num3EditText.text.toString().toDouble()
            val num4 = num4EditText.text.toString().toDouble()
            val num5 = num5EditText.text.toString().toDouble()
            val num6 = num6EditText.text.toString().toDouble()
            val num7 = num7EditText.text.toString().toDouble()
            val num8 = num8EditText.text.toString().toDouble()

            val result1 = num1 - num5
            val result2 = num2 - num6
            val result3 = num3 - num7
            val result4 = num4 - num8
            result1TextView.text = result1.toString()
            result2TextView.text = result2.toString()
            result3TextView.text = result3.toString()
            result4TextView.text = result4.toString()
        }

        multiplyButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val num3 = num3EditText.text.toString().toDouble()
            val num4 = num4EditText.text.toString().toDouble()
            val num5 = num5EditText.text.toString().toDouble()
            val num6 = num6EditText.text.toString().toDouble()
            val num7 = num7EditText.text.toString().toDouble()
            val num8 = num8EditText.text.toString().toDouble()

            val result1 = (num1 * num5)+(num2 * num7)
            val result2 = (num1 * num6)+(num2 * num8)
            val result3 = (num3 * num5)+(num4 * num7)
            val result4 = (num3 * num6)+(num4 * num8)
            result1TextView.text = result1.toString()
            result2TextView.text = result2.toString()
            result3TextView.text = result3.toString()
            result4TextView.text = result4.toString()
        }


        resetButton.setOnClickListener {
            num1EditText.setText("")
            num2EditText.setText("")
            num3EditText.setText("")
            num4EditText.setText("")
            num5EditText.setText("")
            num6EditText.setText("")
            num7EditText.setText("")
            num8EditText.setText("")

            result1TextView.text = ""
            result2TextView.text = ""
            result3TextView.text = ""
            result4TextView.text = ""
        }
    }
}
