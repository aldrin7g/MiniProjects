package com.example.app

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button : Button = findViewById(R.id.run)
        button.setOnClickListener {
            dice()
        }
    }
    fun dice(){
        val a = roll()
        val b = roll()
        val c = roll()
        val image : ImageView = findViewById(R.id.imageView2)
        val image2 : ImageView = findViewById(R.id.imageView)
        val image3 : ImageView = findViewById(R.id.imageView3)
        val result : TextView = findViewById(R.id.textView2)
        when(a) {
            1 -> image.setImageResource(R.drawable.dice_1)
            2 -> image.setImageResource(R.drawable.dice_2)
            3 -> image.setImageResource(R.drawable.dice_3)
            4 -> image.setImageResource(R.drawable.dice_4)
            5 -> image.setImageResource(R.drawable.dice_5)
            6 -> image.setImageResource(R.drawable.dice_6)
        }
        when(b) {
            1 -> image2.setImageResource(R.drawable.dice_1)
            2 -> image2.setImageResource(R.drawable.dice_2)
            3 -> image2.setImageResource(R.drawable.dice_3)
            4 -> image2.setImageResource(R.drawable.dice_4)
            5 -> image2.setImageResource(R.drawable.dice_5)
            6 -> image2.setImageResource(R.drawable.dice_6)
        }
        when(c) {
            1 -> image3.setImageResource(R.drawable.dice_1)
            2 -> image3.setImageResource(R.drawable.dice_2)
            3 -> image3.setImageResource(R.drawable.dice_3)
            4 -> image3.setImageResource(R.drawable.dice_4)
            5 -> image3.setImageResource(R.drawable.dice_5)
            6 -> image3.setImageResource(R.drawable.dice_6)
        }
        if((a == b) && (b == c) && (c == a)){
            result.text = "Game Won!"
        }
        else {
            result.text = "Game Lost!"
        }
    }

    private fun findViewById(imageView2: Int): ImageView {

    }

    fun roll():Int{
        return  (1..6).random()
    }
}