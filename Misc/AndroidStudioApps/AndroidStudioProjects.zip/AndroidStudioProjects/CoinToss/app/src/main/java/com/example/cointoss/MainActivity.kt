package com.example.cointoss

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button: Button = findViewById(R.id.button)
        button.setOnClickListener {
            coin()
        }
    }

    fun coin() {
        val a = roll()
        val image: ImageView = findViewById(R.id.imageView)
        val result: TextView = findViewById(R.id.textView)
        when (a) {
            1 -> image.setImageResource(R.drawable.pngwing_com__1_)
            2 -> image.setImageResource(R.drawable.pngwing_com)
        }
        if (a == 1) {
            result.text = "Head"
        } else {
            result.text = "Tail"
        }
    }
        fun roll(): Int {
            return (1..2).random()
        }
    }
