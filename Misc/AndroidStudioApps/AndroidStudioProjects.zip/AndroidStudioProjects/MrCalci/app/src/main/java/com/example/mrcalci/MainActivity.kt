package com.example.mrcalci

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    private lateinit var num1EditText: TextInputEditText
    private lateinit var num2EditText: TextInputEditText
    private lateinit var resultTextView: TextView
    private lateinit var addButton: Button
    private lateinit var subtractButton: Button
    private lateinit var multiplyButton: Button
    private lateinit var divideButton: Button
    private lateinit var resetButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1EditText = findViewById(R.id.num3EditText)
        num2EditText = findViewById(R.id.num2EditText)
        resultTextView = findViewById(R.id.textView2)
        addButton = findViewById(R.id.button)
        subtractButton = findViewById(R.id.button2)
        multiplyButton = findViewById(R.id.button3)
        divideButton = findViewById(R.id.button4)
        resetButton = findViewById(R.id.button6)

        addButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val result = num1 + num2
            resultTextView.text = result.toString()
        }

        subtractButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val result = num1 - num2
            resultTextView.text = result.toString()
        }

        multiplyButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            val result = num1 * num2
            resultTextView.text = result.toString()
        }

        divideButton.setOnClickListener {
            val num1 = num1EditText.text.toString().toDouble()
            val num2 = num2EditText.text.toString().toDouble()
            if (num2 == 0.0) {
                resultTextView.text = ""
            } else {
                val result = num1 / num2
                resultTextView.text = result.toString()
            }
        }
        resetButton.setOnClickListener {
            num1EditText.setText("")
            num2EditText.setText("")
            resultTextView.text = ""
        }
    }
}
